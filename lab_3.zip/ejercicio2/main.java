public class main
{
    public static void main(String[]args)
    {

        Hertz hertz;
        hertz = new Hertz();

        hertz.llenar_estacionamiento();
        hertz.arrendar_auto();
        hertz.eleccion_auto();

    }
}
