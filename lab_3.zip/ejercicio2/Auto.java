public class Auto
{
    private String modelo;
    private int capacidad_estanque;
    private int kilometraje;

    public Auto(String modelo, int capacidad_estanque, int kilometraje) {
        this.modelo = modelo;
        this.capacidad_estanque = capacidad_estanque;
        this.kilometraje = kilometraje;
    }

    public int getCapacidad_estanque() {
        return capacidad_estanque;
    }

    public void setCapacidad_estanque(int capacidad_estanque) {
        this.capacidad_estanque = capacidad_estanque;
    }

    public int getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }

    public Auto(String modelo) {
        this.modelo = modelo;
    }


    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;

    }
}
