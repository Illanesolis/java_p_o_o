import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;

public class Hertz
{
    Random random = new Random(System.currentTimeMillis());
    Auto auto;
    ArrayList<Auto> estacionamiento = new ArrayList<Auto>();
    int espacios=0;
    Scanner scanner = new Scanner(System.in);
    public void llenar_estacionamiento() {
        while (espacios < 10)
        {
            int tipo_auto = 0, k=0;
            tipo_auto = random.nextInt(3)+1;
            //estacionamiento.add(auto);
            switch (tipo_auto)
            {
                case 1 : k = random.nextInt(2001);
                         auto = new Auto( " Peugot207 ",40,k);
                         estacionamiento.add(auto);
                         espacios++;
                         break;

                case 2: k = random.nextInt(2001);
                        auto = new Auto(" Mazda2 ",20,k);
                        estacionamiento.add(auto);
                        espacios++;
                        break;

                case 3: k = random.nextInt(2001);
                        auto = new Auto(" JeepFull ",60,k);
                        estacionamiento.add(auto);
                        espacios++;
                        break;

            }
        }



    }
    public void arrendar_auto()
    {
        int eleccion_auto=1;
        for(Auto x :estacionamiento)
        {
            System.out.println(" -----------------------------------------------------------------------------------------------------");
            System.out.print("[" + eleccion_auto + "]   " + "modelo del auto : " + x.getModelo() + "|");
            System.out.print(" kilometraje del auto : " + x.getKilometraje() + "|");
            System.out.println("capacidad de estanque del auto : " + x.getCapacidad_estanque() + "|");
            eleccion_auto++;
            System.out.println(" -----------------------------------------------------------------------------------------------------");

        }

    }
    public void eleccion_auto()
    {
        System.out.println(" -----------------------------------------------------------------------------------------------------");
        System.out.println(" Ingrese el numero del auto que desea seleccionar ");
        int auto_elejido=scanner.nextInt();
        System.out.println(" -----------------------------------------------------------------------------------------------------");
        System.out.print("Auto seleccionado "+"["+ auto_elejido +"]"+ " modelo : "+" | " + estacionamiento.get(auto_elejido-1).getModelo() );
        System.out.print( "kilometraje : " + estacionamiento.get(auto_elejido-1).getKilometraje() +" | ");
        System.out.println( "capacidad de estanque  : " + estacionamiento.get(auto_elejido-1).getCapacidad_estanque()+" | ");
        System.out.println( " PORFAVOR DEVOLVER AUTO EN POSICION  : " + ((auto_elejido)-1));
        System.out.println(" -----------------------------------------------------------------------------------------------------");




    }
}
