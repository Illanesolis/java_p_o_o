public class main
{
    public static void main(String[]args)
    {

            Control_historico control_historico;
            control_historico = new Control_historico();
            control_historico.menu_seleccion_auto();

    }

}
