import java.util.Scanner;
public class Control_historico
{
    Hertz hertz=new Hertz();

    Scanner scanner = new Scanner(System.in);
        public void menu_seleccion_auto()
        {
            int menu=4;
            while(menu!=0)
            {

                System.out.println("(1)"+ (" ver autos arrendados "));
                System.out.println("(2)"+ (" ver autos estacionados "));
                System.out.println("(0)"+ (" salir del menu  "));
                menu=scanner.nextInt();

                switch (menu)
                {
                    case 1: hertz.mostrar_autos_arrendados();
                            break;

                    case 2: hertz.mostrar_autos_detenidos();
                            break;


                }


            }

        }

}
