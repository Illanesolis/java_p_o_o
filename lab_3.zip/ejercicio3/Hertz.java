import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;

public class Hertz
{
    Random random = new Random(System.currentTimeMillis());
    Auto auto;
    ArrayList<Auto> estacionamiento = new ArrayList<Auto>();
    int espacios=0;
    Scanner scanner = new Scanner(System.in);
    public void llenar_estacionamiento() {
        while (espacios < 10)
        {
            int tipo_auto = 0, k=0;
            tipo_auto = random.nextInt(3)+1;
            int estado_estacionado=random.nextInt(2);
            switch (tipo_auto)
            {
                case 1 : k = random.nextInt(2001);
                    auto = new Auto( " Peugot207 ",40,k,estado_estacionado);
                    estacionamiento.add(auto);
                    espacios++;
                    break;

                case 2: k = random.nextInt(2001);
                    auto = new Auto(" Mazda2 ",20,k,estado_estacionado);
                    estacionamiento.add(auto);
                    espacios++;
                    break;

                case 3: k = random.nextInt(2001);
                    auto = new Auto(" JeepFull ",60,k,estado_estacionado);
                    estacionamiento.add(auto);
                    espacios++;
                    break;

            }
        }



    }

    public void mostrar_autos_arrendados()
    {
        int eleccion_auto1=1;
        for(Auto x :estacionamiento)
        {
            if(x.getEstado()==1)
            {
                System.out.println(" -----------------------------------------------------------------------------------------------------");
                System.out.print("El auto fue arrendado por la persona numero : " +((eleccion_auto1)) + "|");
                System.out.print("[" + eleccion_auto1 + "]   " + "modelo del auto : " + x.getModelo() + "|");
                System.out.print(" kilometraje del auto : " + x.getKilometraje() + "|");
                System.out.println("capacidad de estanque del auto : " + x.getCapacidad_estanque() + "|");
                System.out.print("estacionamiento del auto : " +((eleccion_auto1)-1) + "|");
                eleccion_auto1++;
                System.out.println(" -----------------------------------------------------------------------------------------------------");

            }

        }


    }
    public void mostrar_autos_detenidos()
    {
        int eleccion_auto2=1;
        for(Auto y :estacionamiento)
        {
            if(y.getEstado()==0)
            {
                System.out.println(" -----------------------------------------------------------------------------------------------------");
                System.out.print("[" + eleccion_auto2 + "]   " + "modelo del auto : " + y.getModelo() + "|");
                System.out.print(" kilometraje del auto : " + y.getKilometraje() + "|");
                System.out.println("capacidad de estanque del auto : " + y.getCapacidad_estanque() + "|");
                System.out.print("estacionamiento del auto : " +((eleccion_auto2)-1) + "|");
                eleccion_auto2++;
                System.out.println(" -----------------------------------------------------------------------------------------------------");

            }

        }


    }



}
