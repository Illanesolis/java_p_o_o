import java.util.ArrayList;
public class Cuestionario
{
    private String pregunta;

    public Cuestionario(String pregunta) {
        this.pregunta = pregunta;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }
}
