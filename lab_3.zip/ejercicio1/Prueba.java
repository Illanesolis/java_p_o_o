import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Prueba
{
    Cuestionario cuestionario;
    int preguntas=0;
    ArrayList<Cuestionario> prueba = new ArrayList<Cuestionario>();
    Scanner scanner = new Scanner(System.in);
    Random random = new Random(System.currentTimeMillis());
    public void llenar_prueba()
    {
        while (preguntas<10)
        {
            cuestionario= new Cuestionario(" pregunta " + preguntas+1);
            prueba.add(cuestionario);
            preguntas++;

        }
    }


    public void todas_las_preguntas()
    {   int numero_pregunta=0;
       for(Cuestionario x:prueba)
       {
           System.out.println(" -----------------------------------------------------------------------------------------------------");
           System.out.println("["+(numero_pregunta+1)+"]"+x.getPregunta());
           System.out.println(" -----------------------------------------------------------------------------------------------------");

           numero_pregunta++;
       }
    }

    int crear_prueba;
    public void eleccion_preguntas()
    {

        System.out.println(" -----------------------------------------------------------------------------------------------------");
        System.out.println(" Ingrese 1 para generar la prueba :");
        int numero_pregunta=0;
        numero_pregunta=random.nextInt(10);
        crear_prueba = scanner.nextInt();
        if(crear_prueba==1)
        {
            for(int i=0; i<5;i++)
            {

                System.out.println("pregunta numero  :" + numero_pregunta );

            }

        }



    }




}
