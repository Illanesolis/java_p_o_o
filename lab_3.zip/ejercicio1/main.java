public class main
{
    public static void main(String[]args)
    {
        Prueba prueba;
        prueba=new Prueba();
        prueba.todas_las_preguntas();
        prueba.llenar_prueba();


    }
}
